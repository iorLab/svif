#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, json, shutil, subprocess
from pathlib import Path

HERE = Path(__file__).resolve().parent
MANIFEST = json.loads((HERE / "manifest.json").read_text(encoding="utf-8"))

def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()

def git(repo: Path, *args: str) -> str:
    return subprocess.check_output(["git", "-C", str(repo), *args], text=True).strip()

def require_repo(repo: Path, label: str) -> None:
    if not (repo / ".git").exists():
        raise SystemExit(f"{label}: not a normal Git checkout: {repo}")
    branch = git(repo, "branch", "--show-current")
    if branch != MANIFEST["branch_required"]:
        raise SystemExit(f"{label}: expected branch {MANIFEST['branch_required']!r}, got {branch!r}")
    if subprocess.run(["git", "-C", str(repo), "diff", "--quiet"]).returncode != 0:
        raise SystemExit(f"{label}: working tree has tracked modifications; start from a clean checkout")
    if subprocess.run(["git", "-C", str(repo), "diff", "--cached", "--quiet"]).returncode != 0:
        raise SystemExit(f"{label}: index has staged modifications; start from a clean checkout")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--svif-repo", type=Path, required=True)
    ap.add_argument("--agnir-repo", type=Path, required=True)
    ap.add_argument("--stage", action="store_true", help="git add the materialized files after verification")
    args = ap.parse_args()

    repos = {"svif": args.svif_repo.resolve(), "agnir": args.agnir_repo.resolve()}
    for label, repo in repos.items():
        require_repo(repo, label)

    # Verify every payload before touching a repository.
    for source_rel, spec in MANIFEST["targets"].items():
        src = HERE / source_rel
        if not src.exists():
            raise SystemExit(f"missing payload: {source_rel}")
        got = sha256(src)
        if got != spec["sha256"]:
            raise SystemExit(f"payload SHA mismatch: {source_rel}: {got} != {spec['sha256']}")

    touched = {"svif": [], "agnir": []}
    for source_rel, spec in MANIFEST["targets"].items():
        src = HERE / source_rel
        dst = repos[spec["repository"]] / spec["target"]
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(src, dst)
        got = sha256(dst)
        if got != spec["sha256"]:
            raise SystemExit(f"post-copy SHA mismatch: {dst}: {got} != {spec['sha256']}")
        touched[spec["repository"]].append(spec["target"])

    for label, paths in touched.items():
        print(f"{label}: materialized {len(paths)} files with exact SHA-256 verification")
        if args.stage:
            subprocess.check_call(["git", "-C", str(repos[label]), "add", "--", *paths])
            print(f"{label}: staged verified brand binaries")

    print("\nPASS: all brand binaries materialized byte-exactly.")
    print("Next: fetch/recheck origin/main, reconcile if it moved, run repository CI/conformance,")
    print("checkpoint Agnir continuity, then commit/push the staged files. Do not merge a stale Draft PR.")

if __name__ == "__main__":
    main()
