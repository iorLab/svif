# Svif / Agnir byte-safe brand integration handoff

This bundle closes the only integration step that the current ChatGPT execution bridge cannot safely perform: pushing larger PNG payloads byte-for-byte into Git.

## What is inside

- the three byte-exact Principal-approved 10:42 AM reference boards;
- the current complete Svif raster production package;
- the current complete Agnir PNG delivery package;
- `manifest.json` with every payload SHA-256 and exact repository target path;
- `apply_brand_binaries.py`, which refuses the wrong branch, verifies every payload before copying, verifies every destination after copying, and can stage the files.

## Required repository state

Use fresh local/Codex checkouts of:

- `iorLab/svif`
- `iorLab/agnir`

Check out `brand/identity-system` in each repository. Before running the script, fetch `origin/main`. If either brand branch is behind main, reconcile latest main first; do not materialize binaries onto a stale branch and then guess conflicts.

## Apply

```bash
python apply_brand_binaries.py \
  --svif-repo /path/to/svif \
  --agnir-repo /path/to/agnir \
  --stage
```

The script does **not** commit or push. That is deliberate: the next executor must perform the normal Agnir checkpoint/reconciliation before the repository commit.

## After apply

For each repository:

1. inspect the staged paths and SHA-256 receipts;
2. re-check latest `origin/main`; reconcile again if it moved;
3. run the repository's canonical tests/conformance;
4. checkpoint branch-local Agnir continuity if materially changed;
5. commit and push `brand/identity-system`;
6. require the existing Draft brand→main PR synthetic-merge CI to be green on the final head;
7. only then consider merging the Draft PR.

Do not regenerate or reinterpret any artwork. The files in this bundle are the locked production/reference payloads.
